

        <a name="top"></a>
        <div class="android-be-together-section mdl-typography--text-center" >




          <div class="logo-font android-slogan">Design your own IOT application</div>

          <div class="logo-font-docs android-sub-slogan">User friendly iot platform allow you to create your IOT application in a couple of minutes.</div>

        </div>
  

  <div >
            <h2 class="copyright">© 2017 eduiot Technologies</h2>
  </div>

