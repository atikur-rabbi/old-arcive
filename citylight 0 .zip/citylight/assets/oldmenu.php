 <?php
                if($row["ui"]==99){
                  require_once 'assets/devicemenu.php'; 
                  
                   echo '';
                }
                if($row["ui"]==98){
                  require_once 'assets/sensormenu.php'; 
                  
                   echo '';
                }

                else{
                     echo '<div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">';
                     echo '<div style="background-color: #4D9CD0;"class="demo-card-wide mdl-card mdl-shadow--4dp ">';
                     echo ' <div class="mdl-card__title" align="center">';
                     echo '<h2 class="mdl-card__title-text">'. $row["devicename"].'</h2>';
                     echo '  </div>';
                     echo '<div class="mdl-card__supporting-text">';


                     echo '<a href="sensor.php">';



                     echo '<div class="mdl-grid">';
                     echo '  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone">';



                     echo '<i class="material-icons" style="color: white; font-size: 60px;"  >wifi_tethering</i>';


                     echo '</div></div></a>';
                     echo ' <div class="mdl-card__menu">';
                     echo '<button id="demo-menu-lower-right'. $row["id"].'" class="mdl-button mdl-js-button mdl-button--icon">';
                     echo '<i class="material-icons">more_vert</i></button>';
                     echo '<ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="demo-menu-lower-right'. $row["id"].'">';
                     echo ' <a href=updatedevice.php><li class="mdl-menu__item"><i class="material-icons">autorenew</i> Update</li></a> ';



                     echo  "<a href='deletedevice.php?dname=" . $row["devicename"]."&ekey=" . $row["ekey"]."'>"; 


                     echo '<li class="mdl-menu__item"><i class="material-icons">delete_forever</i> Delete</li></a> </ul></div></div></div></div>';

                }

                ?>