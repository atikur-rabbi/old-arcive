

<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "sensor";

 

$sql = "SELECT id, devicename, username, ekey, command, udate FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        //echo  $row["command"];
        //echo  "<br>";
       // echo  $row["udate"];
       $s = $row["command"];
            }
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>



<style>
.demo-card-wide.mdl-card {
  width: auto;
  background-color: #5B426D;
  margin: 0;
}
.mdl-card__title {
  color: #fff;
  height: 60px;
  
}


</style>


 <div class="mdl-grid">

 <div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">

<div style="background-color: #41CAC6;"class="demo-card-wide mdl-card mdl-shadow--4dp ">
  <div class="mdl-card__title">
    <h2 class="mdl-card__title-text">Temperature</h2>
  </div>
  <div class="mdl-card__supporting-text">
  

  <div class="mdl-grid">
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"><img src="sensors/temp.png"  width="100px" height="100px"></div>
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone">  <h3><?php  echo $s[1].$s[2]?>*C</h3></div>
 </div>
  </div>
</div>
</div>



<div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">
<div style="background-color: #4D9CD0;"class="demo-card-wide mdl-card mdl-shadow--4dp">
   <div class="mdl-card__title">
       <h2 class="mdl-card__title-text">Humidity</h2>
   </div>
  <div class="mdl-card__supporting-text">
    <div class="mdl-grid">
      <div   class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"><img src="sensors/humidity.png"  width="100px" height="100px"></div>
      <div   class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone">  <h3><?php  echo $s[7].$s[8]?>%</h3></div>
    </div>
  </div>
</div>
</div>




 <div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">

<div style="background-color: #5B5489;"class="demo-card-wide mdl-card mdl-shadow--4dp">
  <div class="mdl-card__title">
    <h2 class="mdl-card__title-text">Gas Sensor</h2>
  </div>
  <div class="mdl-card__supporting-text">

    <div class="mdl-grid">
  <div   class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"><img src="sensors/gas.png" width="100px" height="100px"></div>
  <div   class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone">  <h3><?php  echo $s[19].$s[20].$s[21]?>ppm</h3></div>
 </div>
  
  </div>
</div>
</div>

 <div  class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">

<div style="background-color: #5B426D;"class="demo-card-wide mdl-card mdl-shadow--4dp">
  <div class="mdl-card__title">
    <h2 class="mdl-card__title-text">Water Level</h2>
  </div>
  <div class="mdl-card__supporting-text">

    <div class="mdl-grid">
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"><img src="sensors/water.png" width="100px" height="100px"></div>
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"> <h3> <?php  echo $s[14].$s[15].$s[16]?>cm</h3></div>
 </div>
  
  </div>
</div>
</div>


 <div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">

<div style="background-color: #4975AB;"class="demo-card-wide mdl-card mdl-shadow--4dp">
  <div class="mdl-card__title">
    <h2 class="mdl-card__title-text">Motion Sensor</h2>
  </div>
  <div class="mdl-card__supporting-text">

    <div class="mdl-grid">
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"><img src="sensors/motion.png" width="100px" height="100px"></div>
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone">  <h3><?php  echo $s[18]?></h3></div>
 </div>
  
  </div>
</div>
</div>








