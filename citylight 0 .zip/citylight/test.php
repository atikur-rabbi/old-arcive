<?php
require_once 'assets/head2.php';
?>

<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "test";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        $t = $row["command"];
        
        }
    }
} else {
    echo "0 results";
}


//echo $t[0];  
//echo $t[1];
//echo $t[2];

//echo $t[3];  
//echo $t[4];
//echo $t[5];

//echo $t[6];  
//echo $t[7];

for ($x = 0; $x <= 3; $x++) {
if ($t[$x]){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
}

$c[4]=10*$t[4] + $t[5] ;
 //echo $c[4];

$link->close();
?>


  <script>

 function updatefrom(){
document.getElementById("form").submit();
 alert('form was submitted');
}
      $(function () {

        $('form').on('change', function (e) {

          e.preventDefault();
      
          $.ajax({
            type: 'post',
            url: 'test3.php',
            data: $('form').serialize(),
            success: function () {
             // alert('form was submitted');
            }
          });

        });

      });



    </script>



    <div class="flex-container">
    <form  id="cform">

<label for="switch1" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[0]' type="checkbox" id="switch1" class="mdl-switch__input" value = '1' <?php  echo $c[0]?>>
  <span class="mdl-switch__label">Light</span>
</label>
<label for="switch2" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
    <span class="mdl-switch__label">Fan</span>
  <input name = 'check[1]' type="checkbox" id="switch2" class="mdl-switch__input" value = '1'<?php  echo $c[1]?>> 
</label>
<label for="switch3" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[2]' type="checkbox" id="switch3" class="mdl-switch__input" value = '1' <?php  echo $c[2]?>>
  <span class="mdl-switch__label">TV</span>
</label>
<label for="switch4"  class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[3]' type="checkbox" id="switch4" class="mdl-switch__input" value = '1' <?php  echo $c[3]?>> 
  <span class="mdl-switch__label">Pump</span>
</label>

<input class="mdl-slider mdl-js-slider" type="range"
  min="0" max="100"  name = 'check[4]' tabindex="0" value="<?php echo  $c[4];  ?>">


     
    </form>
  </div>






<!-- List with avatar and controls -->
<style>
.demo-list-control {
  width: auto;
}

.demo-list-radio {
  display: inline;
}
</style>

<ul class="demo-list-control mdl-list">
  <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">
      <i class="material-icons  mdl-list__item-avatar">person</i>
      Bryan Cranston
    </span>
    <span class="mdl-list__item-secondary-action">
      <label class="mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect" for="list-checkbox-1">
        <input type="checkbox" id="list-checkbox-1" class="mdl-checkbox__input" checked />
      </label>
    </span>
  </li>
  <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">
      <i class="material-icons  mdl-list__item-avatar">person</i>
      Aaron Paul
    </span>
    <span class="mdl-list__item-secondary-action">
      <label class="demo-list-radio mdl-radio mdl-js-radio mdl-js-ripple-effect" for="list-option-1">
        <input type="radio" id="list-option-1" class="mdl-radio__button" name="options" value="1" checked />
      </label>
    </span>
  </li>
  <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">
      <i class="material-icons  mdl-list__item-avatar">person</i>
      Bob Odenkirk
    </span>
    <span class="mdl-list__item-secondary-action">
      <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="list-switch-1">
        <input type="checkbox" id="list-switch-1" class="mdl-switch__input" checked />
      </label>
    </span>
  </li>
</ul>





<div class="demo-card-wide mdl-card mdl-shadow--2dp">
  <div class="mdl-card__title">
    <h2 class="mdl-card__title-text">Welcome</h2>
  </div>
  <div class="mdl-card__supporting-text">
    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    Mauris sagittis pellentesque lacus eleifend lacinia...
  </div>
  <div class="mdl-card__actions mdl-card--border">
    <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
      Get Started
    </a>
  </div>
  <div class="mdl-card__menu">
    <!-- Right aligned menu below button -->
<button id="demo-menu-lower-right"
        class="mdl-button mdl-js-button mdl-button--icon">
  <i class="material-icons">more_vert</i>
</button>

<ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="demo-menu-lower-right">
  <li class="mdl-menu__item">Some Action</li>
  <li class="mdl-menu__item">Another Action</li>
  <li disabled class="mdl-menu__item">Disabled Action</li>
  <li class="mdl-menu__item">Yet Another Action</li>
</ul>
  </div>
</div>




  <div class="mdl-grid">
  <div class="mdl-cell mdl-cell--6-col mdl-cell--8-col-tablet">6 (8 tablet)</div>
  <div class="mdl-cell mdl-cell--4-col mdl-cell--6-col-tablet">4 (6 tablet)</div>
  <div class="mdl-cell mdl-cell--2-col mdl-cell--4-col-phone">2 (4 phone)</div>
</div>



  <div class="mdl-grid">

  <div class="mdl-cell mdl-cell--6-col mdl-cell--6-col-tablet mdl-cell--2-col-phone">2 (4 phone)</div>
  <div class="mdl-cell mdl-cell--6-col mdl-cell--6-col-tablet mdl-cell--2-col-phone">2 (4 phone)</div>
  <div class="mdl-cell mdl-cell--12-col mdl-cell--3-col-tablet mdl-cell--2-col-phone">2 (4 phone)</div>
  <div class="mdl-cell mdl-cell--12-col mdl-cell--3-col-tablet mdl-cell--2-col-phone">2 (4 phone)</div>
  <div class="mdl-cell mdl-cell--6-col mdl-cell--3-col-tablet mdl-cell--2-col-phone">2 (4 phone)</div>
  <div class="mdl-cell mdl-cell--6-col mdl-cell--3-col-tablet mdl-cell--2-col-phone">2 (4 phone)</div>
</div>






</div>
  </div>

<?php
require_once 'assets/end.php';
?>