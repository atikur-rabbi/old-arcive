<?php


// Include config file
require_once 'config.php';

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if (isset($_POST['dmax']))
     {
        
        for ($x = 1; $x <= $_POST['dmax']; $x++) {
        $uid =   $_POST['a'][$x];
        echo   $uid ;
        echo  "   ";

        

        $cmd = isset($_POST[$_POST['a'][$x]])? 1 : 0;
        echo   $cmd ;
        echo   "<br>";

        $sq1 = "UPDATE devices SET command='$cmd' WHERE id=$uid";

        if ($link->query($sq1) === TRUE) {
      
           ;// echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }

        }
        
     }






?>
<form id="cform" method="post">
    


     <input type="checkbox" name = '37' id="d1" value = '1' onchange = "updatefrom()">
     <input type="checkbox" name = '20' id="d2" value = '1' onchange = "updatefrom()">
     <input type="checkbox" name = '35' id="d3" value = '1' onchange = "updatefrom()">

     <input hidden name = 'a[1]' value = '37' onchange = "updatefrom()">
     <input hidden name = 'a[2]' value = '20' onchange = "updatefrom()">
     <input hidden name = 'a[3]' value = '35' onchange = "updatefrom()">

  
     <input hidden name = 'dmax' value = '3' onchange = "updatefrom()">


</form>

<script>
function updatefrom(){
    document.getElementById("cform").submit();
}
</script>

