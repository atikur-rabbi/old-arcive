<div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">

<div style="background-color: #41CAC6;"class="demo-card-wide mdl-card mdl-shadow--4dp ">
  <div class="mdl-card__title" align="center">
    <h2 class="mdl-card__title-text">Home </h2>
  </div>
  <div class="mdl-card__supporting-text">
  
<a href="test2.php">
  <div class="mdl-grid">
  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone"><i class="material-icons" style="color: white; font-size: 60px;"  >home</i>  </div>
 </div>
</a>
  <div class="mdl-card__menu">
    <!-- Right aligned menu below button -->
<button id="demo-menu-lower-right"
        class="mdl-button mdl-js-button mdl-button--icon">
  <i class="material-icons">more_vert</i>
</button>

<ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="demo-menu-lower-right">
     <a href=updatedevice.php><li class="mdl-menu__item"><i class="material-icons">autorenew</i> Update</li></a> 
  <a href="deletedevice.php?dname=d2&ekey=12345678"> <li class="mdl-menu__item"><i class="material-icons">delete_forever</i> Delete</li></a> </ul></div></div></div></div>


