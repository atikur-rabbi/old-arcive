<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>


<?php
require_once 'assets/head2.php';
?>





<style>
.demo-card-wide.mdl-card {
  width: auto;
  background-color: #5B426D;
  margin: 0;
}
.mdl-card__title {
  color: #fff;
  height: 60px;
  
}
</style>


 <div class="mdl-grid">



    <?php

// Include config file
require_once 'config.php';

 

$sql = "SELECT id, devicename, username, ekey, command, ui FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["username"]==$_SESSION['username']){
       // echo  "<h3><br><a href='controldevice.php'> Devicename: " . $row["devicename"]."<br> Key: " . $row["ekey"]."</a></h3><br>";
        // Buttons for other control 
      //  echo  "<div><a href='deletedevice.php?dname=" . $row["devicename"]."&ekey=" . $row["ekey"]."'> Delete </a></div>  <br>"; 
                
                
                if($row["ui"]==99){
                  require_once 'assets/devicemenu.php'; 
                  
                   echo '';
                }
                if($row["ui"]==98){
                  require_once 'assets/sensormenu.php'; 
                  
                   echo '';
                }
                else{
                     echo '<div class="mdl-cell mdl-cell--6-col  mdl-cell--8-col-tablet">';
                     echo '<div style="background-color: #4D9CD0;"class="demo-card-wide mdl-card mdl-shadow--4dp ">';
                     echo ' <div class="mdl-card__title" align="center">';
                     echo '<h2 class="mdl-card__title-text">'. $row["devicename"].'</h2>';
                     echo '  </div>';
                     echo '<div class="mdl-card__supporting-text">';


                     echo '<a href="sensor.php">';



                     echo '<div class="mdl-grid">';
                     echo '  <div  class="mdl-cell mdl-cell--6-col  mdl-cell--3-col-tablet mdl-cell--2-col-phone">';



                     echo '<i class="material-icons" style="color: white; font-size: 60px;"  >wifi_tethering</i>';


                     echo '</div></div></a>';
                     echo ' <div class="mdl-card__menu">';
                     echo '<button id="demo-menu-lower-right'. $row["id"].'" class="mdl-button mdl-js-button mdl-button--icon">';
                     echo '<i class="material-icons">more_vert</i></button>';
                     echo '<ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" for="demo-menu-lower-right'. $row["id"].'">';
                     echo ' <a href=updatedevice.php><li class="mdl-menu__item"><i class="material-icons">autorenew</i> Update</li></a> ';



                     echo  "<a href='deletedevice.php?dname=" . $row["devicename"]."&ekey=" . $row["ekey"]."'>"; 


                     echo '<li class="mdl-menu__item"><i class="material-icons">delete_forever</i> Delete</li></a> </ul></div></div></div></div>';

                }
                
                }
        
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>




</div>


<?php
require_once 'assets/end.php';
?>