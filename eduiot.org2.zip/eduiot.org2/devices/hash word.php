<?php
// Include config file

$snm = "asdfgh";

$h_password = password_hash($snm, PASSWORD_DEFAULT);

echo $h_password;


$hash = '$2y$10$yC2U0Pi8Cp/eSkYfG2/akeIXFxdM3QmtSyxC9xwh/vvpera8LHL9S';

if (password_verify($snm , $hash)) {
    echo 'Password is valid!';
} else {
    echo 'Invalid password.';
}

?>

