<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>


<?php
require_once 'assets/head2.php';
?>


<script src="jquery.min.js"></script>
<script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("se_r4.php");
    setTimeout(loadstation, 2000);
}
</script>


<div id="station_data"></div>







<?php
require_once 'assets/end.php';
?>