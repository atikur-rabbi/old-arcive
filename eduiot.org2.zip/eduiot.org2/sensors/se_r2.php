<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "sensor";

 

$sql = "SELECT id, devicename, username, ekey, command, udate FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        //echo  $row["command"];
        //echo  "<br>";
       // echo  $row["udate"];
       $s = $row["command"];
            }
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>
<p id="temp" > Temperatur: <?php  echo $s[1].$s[2]?>*C </p> 
<p id="humidity" > Humidity: <?php  echo $s[7].$s[8]?>% </p>
<p id="distance" > Distance: <?php  echo $s[14].$s[15].$s[16]?>cm </p>
<p id="gas" > Gas: <?php  echo $s[19].$s[20].$s[21]?>ppm </p>

