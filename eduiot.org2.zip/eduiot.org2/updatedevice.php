<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}



// Define variables and initialize with empty values
$devicename = $ekey = $ui = "";
$devicename_err = $ekey_err = $ui_err =  "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate devicename
    if(empty(trim($_POST["devicename"]))){
        $devicename_err = "Please enter a device name.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM devices WHERE devicename = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_devicename);
            
            // Set parameters
            $param_devicename = trim($_POST["devicename"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $devicename_err = "This device is already taken.";
                } else{
                    $devicename = trim($_POST["devicename"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate ekey
    if(empty(trim($_POST['ekey']))){
        $ekey_err = "Please enter a ekey.";     
    } elseif(strlen(trim($_POST['ekey'])) < 6){
        $ekey_err = "ekey must have atleast 6 characters.";
    } else{
        $ekey = trim($_POST['ekey']);
    }
    
        // Validate ui
    if(empty(trim($_POST['ui']))){
        $ui_err = "Please enter a ui.";     
    } else{
        $ui = trim($_POST['ui']);
    }

   
$odname =$_POST['odname'];

$sql = "SELECT id, devicename, username, ekey, command, ui FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ( $row["devicename"]==$odname){
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //echo  $uid;
        }
        }
    }
} else {
    echo "0 results";
}

$sq1 = "UPDATE devices SET devicename = '$devicename', ekey = '$ekey', ui = '$ui' WHERE id=$uid";

$link->query($sq1);




$link->close();
}
?>
 



<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Introducing Lollipop, a sweet new take on Android.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Eduiot | IOT solution </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

    <!-- Page styles -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
    <style type="text/css">
        body{ font: 14px sans-serif;  }
        .wrapper{ width: 350px; padding: 20px; margin: auto ;}
    </style>
  </head>
  <body >
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">

      <div class="android-header mdl-layout__header mdl-layout__header--waterfall">
        <div class="mdl-layout__header-row">
          <span class="android-title mdl-layout-title">
            <img class="android-logo-image" src="images/eduiotc.png">
          </span>
          <!-- Add spacer, to align navigation to the right in desktop -->
          <div class="android-header-spacer mdl-layout-spacer"></div>
          <div class="android-search-box mdl-textfield mdl-js-textfield mdl-textfield--expandable mdl-textfield--floating-label mdl-textfield--align-right mdl-textfield--full-width">
            
         
          </div>
          <!-- Navigation -->
        
          <span class="android-mobile-title mdl-layout-title">
            <img class="android-logo-image-mobile" src="images/eduiotc.png">
          </span>
          <button class="android-more-button mdl-button mdl-js-button mdl-button--icon mdl-js-ripple-effect" id="more-button">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-menu--bottom-right mdl-js-ripple-effect" for="more-button">
            <li ><a class="mdl-menu__item" href="settings.php" >Settings</a></li>
            <li ><a class="mdl-menu__item" href="logout.php" >Sign Out</a></li>
          </ul>
        </div>
      </div>

      <div class="android-drawer mdl-layout__drawer" class="scrollbar" id="style-3">
        <span class="mdl-layout-title">
          <img class="android-logo-image" src="images/eduiotw.png">
        </span>
        <nav class="mdl-navigation">
          <a class="mdl-navigation__link" href="account.php">Account</a>
          <a class="mdl-navigation__link" href="dashboard.php" >My Devices</a>
          <a class="mdl-navigation__link" href="adddevice.php" >Add Device</a>
          <a class="mdl-navigation__link" href="updatedevice.php" >Update Device</a>
          <a class="mdl-navigation__link" href="logout.php">Sign Out</a>
      
        </nav>
      </div>














      <div class="android-content mdl-layout__content" >
        <a name="top"></a>

 <div class="section mdl-typography--text-center" >


          <div class="wrapper">


         <div class="logo-font android-slogan">Update Device</div>
    
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

          <div class="form-group ">
                 <div class="logo-font-docs android-sub-slogan"> <label>Enter Old Device name:<sup>*</sup></label></div>
                <input type="odname" name="odname" class="form-control" value="">
                <span class="help-block"></span>
            </div>
            
            <div class="form-group ">
                 <div class="logo-font-docs android-sub-slogan"> <label>Device name:<sup>*</sup></label></div>
                <input type="text" name="devicename"class="form-control" value="">
                <span class="help-block"></span>
            </div>    
            <div class="form-group ">
                 <div class="logo-font-docs android-sub-slogan"> <label>ekey:<sup>*</sup></label></div>
                <input type="ekey" name="ekey" class="form-control" value="">
                <span class="help-block"></span>
            </div>

         <div class="form-group ">
                 <div class="logo-font-docs android-sub-slogan"> <label>ui:<sup>*</sup></label></div>
                <input type="ui" name="ui" class="form-control" value="">
                <span class="help-block"></span>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
            
        </form>
    </div>    



        

</div>



  <div >
            <h2 class="copyright">© 2017 eduiot Technologies</h2>
  </div>
       

        
      </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>


  </body>
</html>
