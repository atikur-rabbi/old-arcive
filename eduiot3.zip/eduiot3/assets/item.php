 <?php
               
                if(($row["ui"]>20)&&($row["ui"]<50)){
                  
                  
                   require'assets/itemui.php';

               }
                else{
                     

                }

 ?>