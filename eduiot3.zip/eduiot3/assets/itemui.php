<li class="mdl-list__item">

 <div class="md-radio">
    <input  type="radio" 
       <?php 
  
  // echo dateDiff( $row["udate"], time());
   date_default_timezone_set('Asia/Dhaka');
$time = strtotime($row["connect"]);

$curtime = time();

if(($curtime-$time) < 60) {     //1800 seconds
  //do stuff
  //echo ($curtime-$time);
  echo 'checked';
}
?>>
    <label for="a"></label>
  </div>




    <span class="mdl-list__item-primary-content">  <img class="ico" src="images/<?php  echo $row["ui"]?>.png" > 
    <?php 
    if($row["ui"]==21)echo 'Light';  
    if($row["ui"]==22)echo 'Fan';  
    if($row["ui"]==23)echo 'TV';  
    if($row["ui"]==24)echo 'Pump';   
    ?>
    </span>






    <label class="input-toggle">
    <input type="checkbox" name = '<?php  echo $row["devicename"];?>' id="<?php  echo $row["devicename"];?>" value = '1' 
    <?php 
    if($row["command"]==1)echo 'checked';  
    ?>> 
    <span></span> </label>
  <br>
  <br>
</label>
  </li>