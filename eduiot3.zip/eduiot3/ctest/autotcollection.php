<?php
// Include config file
require_once 't1.php';
 

?>
