

<?php
require_once 'assets/head2.php';
?>



<script src="jquery.min.js"></script>
<script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("posttest.php");
    setTimeout(loadstation, 2000);
}
</script>
<div id="station_data"></div>




<?php
require_once 'assets/end.php';
?>





