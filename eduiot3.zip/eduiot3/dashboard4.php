<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>


<?php
require_once 'assets/head2.php';
?>





<style>
.demo-card-wide.mdl-card {
  width: auto;
  background-color: #5B426D;
  margin: 0;
}
.mdl-card__title {
  color: #fff;
  height: 60px;
  
}
</style>


 <div class="mdl-grid">



    <?php

// Include config file
require_once 'config.php';

 

$sql = "SELECT id, devicename, username, ekey, command, ui FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["username"]==$_SESSION['username']){
       // echo  "<h3><br><a href='controldevice.php'> Devicename: " . $row["devicename"]."<br> Key: " . $row["ekey"]."</a></h3><br>";
        // Buttons for other control 
      //  echo  "<div><a href='deletedevice.php?dname=" . $row["devicename"]."&ekey=" . $row["ekey"]."'> Delete </a></div>  <br>"; 
                
               require'assets/item.php';
                
                }
        
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>




</div>


<?php
require_once 'assets/end.php';
?>