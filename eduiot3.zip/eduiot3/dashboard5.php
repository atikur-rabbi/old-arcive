<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>


<?php
require_once 'assets/head2.php';
?>

<link rel="stylesheet" href="mdb.css">


  <script>

 function updatefrom(){
document.getElementById("form").submit();
 alert('form was submitted');
}
      $(function () {

        $('form').on('change', function (e) {

          e.preventDefault();
      
          $.ajax({
            type: 'post',
            url: 'test3.php',
            data: $('form').serialize(),
            success: function () {
             // alert('form was submitted');
            }
          });

        });

      });



    </script>







<!-- List with avatar and controls -->
<style>
.mdl-list__item-primary-content {
  width: auto;
  color: white;
}
.ico{
  width:60px;
}

</style>


  <div style="width:80vw; margin: auto;" >



    <form  id="cform">
  <div class="mdl-cell mdl-cell--12-col ">



    <?php

// Include config file
require_once 'config.php';

 

$sql = "SELECT id, devicename, username, ekey, command, udate, ui FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["username"]==$_SESSION['username']){
       // echo  "<h3><br><a href='controldevice.php'> Devicename: " . $row["devicename"]."<br> Key: " . $row["ekey"]."</a></h3><br>";
        // Buttons for other control 
      //  echo  "<div><a href='deletedevice.php?dname=" . $row["devicename"]."&ekey=" . $row["ekey"]."'> Delete </a></div>  <br>"; 
                
               require'assets/item.php';
                
                }
        
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>



</div>


<?php
require_once 'assets/end.php';
?>
