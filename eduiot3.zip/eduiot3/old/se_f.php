<?php


// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}


$snm = "12345678";
$snm2 = "d2";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        //echo  $row["command"];
        $t = $row["command"];
        
        }
    }
} else {
    echo "0 results";
}


//echo $t[0];  
//echo $t[1];
//echo $t[2];

//echo $t[3];  
//echo $t[4];
//echo $t[5];

//echo $t[6];  
//echo $t[7];

for ($x = 0; $x <= 3; $x++) {
if ($t[$x]){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
}

$c[4]=10*$t[6] + $t[7] ;
// echo $c[4];

$link->close();
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Introducing Lollipop, a sweet new take on Android.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Eduiot | IOT solution </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

    <!-- Page styles -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.lime-yellow.min.css" />
    
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
        <style type="text/css">
        body{ font: 14px sans-serif;  }
        .wrapper{ width: 350px; padding: 20px; margin: auto ;}
    </style>

        <link rel="stylesheet" type="text/css" href="button.css" />
        <style>
body{  
    background: #2A3D4F;
    color: #FFF;
    text-align: center;   
  }
h1{
    font-family: Roboto, sans-serif; 
  font-size: 35px; 
  font-weight: 300; 
}
button {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
  font-size: 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text], select {
    width: 60%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
p{
    font-size: 25px;
}
 div.demo{text-align: center; width: 280px; float: left}
 div.demo > p{font-size: 20px}
</style>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
     <script src="jquery.min.js"></script>
    <script src="jquery.knob.min.js"></script>

        <script>

 function updatefrom(){
document.getElementById("cform").submit();
 //alert('form was submitted');
}
      $(function () {

        $('form').on('change', function (e) {

          e.preventDefault();
      
          $.ajax({
            type: 'post',
            url: 'se_u.php',
            data: $('form').serialize(),
            success: function () {
             // alert('form was submitted');
            }
          });

        });

            $('input').on('change', function (f) {

          f.preventDefault();
      
          $.ajax({
            type: 'post',
            url: 'se_u.php',
            data: $('form').serialize(),
            success: function () {
             // alert('form was submitted');
            }
          });

        });

      });



    </script>
    <script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                     

                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                         //updatefrom();
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

                // Example of infinite knob, iPod click wheel
               
            });
        </script>
 <script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("se_r.php");
    setTimeout(loadstation, 1000);
}
</script>
<script>

var xmlhttp = new XMLHttpRequest();
var x;

xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        myObj = JSON.parse(this.responseText);
        var  x= myObj.name;
        var x1= x[6]+x[7];

        if (x[0]==1){
         $( "#check[0]").prop('checked', true);
        }

        var x2= parseInt(x1);
        document.getElementById("demo1").innerHTML = x1;
        document.getElementById("input1").innerHTML = x2;
    }
};
xmlhttp.open("GET", "se.php", true);
xmlhttp.send();



</script>




	
    </head>


 <body>


   <p id="station_data"></p>

<form  id="cform" method="post">
        <div class="mdl-grid">
               <div class="mdl-cell mdl-cell--2-col">
                   <h1>Light</h1>
               </div>
                <div class="switch demo3 mdl-cell mdl-cell--2-col">
					<input type = 'checkbox' name = 'check[0]' value = '1' <?php  echo $c[0]?>> 
					<label><i></i></label>
				</div>
        </div>
        <div class="mdl-grid">
                <div class="mdl-cell mdl-cell--2-col">
                   <h1>Fan</h1>
               </div>
                <div class="switch demo3 mdl-cell mdl-cell--2-col">
					<input type = 'checkbox' name = 'check[1]' value = '1' <?php  echo $c[1]?> > 
					<label><i></i></label>
				</div>
        </div>
        <div class="mdl-grid">

                <div class="mdl-cell mdl-cell--2-col">
                   <h1>TV</h1>
               </div>
                <div class="switch demo3 mdl-cell mdl-cell--2-col">
					<input type = 'checkbox' name = 'check[2]' value = '1' <?php  echo $c[2]?> > 
					<label><i></i></label>
				</div>
        </div>
        <div class="mdl-grid">

                <div class="mdl-cell mdl-cell--2-col">
                   <h1>Pump</h1>
               </div>
                <div class="switch demo3 mdl-cell mdl-cell--2-col">
					<input type = 'checkbox' name = 'check[3]' value = '1' <?php  echo $c[3]?>> 
					<label><i></i></label>
				</div>
        </div>
        <div class="mdl-grid">
                <div class="mdl-cell mdl-cell--2-col">
                   <h1>Speed</h1>
               </div>
              <div class="mdl-cell mdl-cell--8-col">
                   <input  id="input1"  NAME= 'check[4]'   class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron"  data-thickness=".2" value="<?php echo  $c[4];  ?>" data-thickness=".2">
               </div>

         </div>       
                
</form>












    <script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>


  </body>
</html>