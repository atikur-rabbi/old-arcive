<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>





    
    <?php

// Include config file
require_once 'config.php';

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["username"]==$_SESSION['username']){
       // echo  "<h3><a href='controldevice.php'> Devicename: " . $row["devicename"]." ------ " . $row["command"]."</a></h3>";


        
        }
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>


