<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>


<link rel="stylesheet" href="mdb.css">

<!-- List with avatar and controls -->
<style>
.mdl-list__item-primary-content {
  width: auto;
  color: white;
}
.ico{
  width:60px;
}

</style>

  <div style="width:80vw; margin: auto;" >



    <form  id="cform">
  <div class="mdl-cell mdl-cell--12-col ">

    
    <?php

// Include config file
require_once 'config.php';

 

$sql = "SELECT id, devicename, username, ekey, command, udate,connect, ui  FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["username"]==$_SESSION['username']){
        //echo  "<h3><a href='controldevice.php'> Devicename: " . $row["devicename"]." ------ " . $row["command"]."</a></h3>";

               require'assets/item.php';


        
        }
        }
    }
} else {
    echo "0 results";
}




$link->close();
?>


</div>
</div>
</div>


