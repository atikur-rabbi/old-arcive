<?php
require_once 'assets/head2.php';
?>

<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "d2";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        $t = $row["command"];
        
        }
    }
} else {
    echo "0 results";
}


//echo $t[0];  
//echo $t[1];
//echo $t[2];

//echo $t[3];  
//echo $t[4];
//echo $t[5];

//echo $t[6];  
//echo $t[7];

for ($x = 0; $x <= 3; $x++) {
if ($t[$x]){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
}

$c[4]=10*$t[6] + $t[7] ;
 //echo $c[4];

$link->close();
?>


  <script>

 function updatefrom(){
document.getElementById("form").submit();
 alert('form was submitted');
}
      $(function () {

        $('form').on('change', function (e) {

          e.preventDefault();
      
          $.ajax({
            type: 'post',
            url: 'test3.php',
            data: $('form').serialize(),
            success: function () {
             // alert('form was submitted');
            }
          });

        });

      });



    </script>



  <div style="width:80vw; margin: auto;" >



    <form  id="cform">



<!-- List with avatar and controls -->
<style>
.mdl-list__item-primary-content {
  width: auto;
  color: white;
}
.ico{
  width:60px;
}

</style>




  <div class="mdl-cell mdl-cell--12-col ">
  
  <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">  <img class="ico" src="images/fan.png" > Fan</span>
    <span class="mdl-list__item-secondary-action">
<label for="switch2" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
    <span class="mdl-switch__label"></span>
  <input name = 'check[1]' type="checkbox" id="switch2" class="mdl-switch__input" value = '1'<?php  echo $c[1]?>> 
</label>
    </span>
  </li>



 <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">   <img class="ico" src="images/bulb.png" >  Light</span>
    <span class="mdl-list__item-secondary-action">
<label for="switch1" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[0]' type="checkbox" id="switch1" class="mdl-switch__input" value = '1' <?php  echo $c[0]?>>
  <span class="mdl-switch__label"></span>
</label>
    </span>
  </li>
  

  
  <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">  <img class="ico" src="images/tv.png" > TV</span>
    <span class="mdl-list__item-secondary-action">
<label for="switch3" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[2]' type="checkbox" id="switch3" class="mdl-switch__input" value = '1' <?php  echo $c[2]?>>
  <span class="mdl-switch__label"></span>
</label>
    </span>
  </li>
  
  <li class="mdl-list__item">
    <span class="mdl-list__item-primary-content">  <img class="ico" src="images/pump.png" > Pump</span>
    <span class="mdl-list__item-secondary-action">
<label for="switch4"  class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[3]' type="checkbox" id="switch4" class="mdl-switch__input" value = '1' <?php  echo $c[3]?>> 
  <span class="mdl-switch__label"></span>
</label>
  </li>

 <li  class="mdl-list__item">
  <input style="width: 60vw;" class="mdl-slider mdl-js-slider" type="range"
  min="0" max="100"  name = 'check[4]' tabindex="0" value="<?php echo  $c[4];  ?>">
</li>
  </div>
  








     
    </form>
  </div>











</div>
  </div>

<?php
require_once 'assets/end.php';
?>