<?php


// Include config file
require_once 'config.php';

    // if post with name is posted, set value to 1, else to 0
    for ($x = 0; $x <= 3; $x++) {
    $a[$x]= isset($_POST['check'][$x]) ? 1 : 0;
    //echo   $a[$x];
    }
   $a[4]=isset($_POST['check'][4]) ? $_POST['check'][4]: 0;
     $e=100+ $a[4];
    $all= $a[0].$a[1].$a[2].$a[3]."s". $e;

$snm = "12345678";
$snm2 = "d2";
$snm3 = $all;



$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //$ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}

$sq1 = "UPDATE devices SET command='$snm3' WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
      
   ;// echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}


?>
