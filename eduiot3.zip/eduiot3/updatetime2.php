<?php

// Include config file
require_once 'config.php';

$snm = $_GET["ekey"];
$snm2 = $_GET["dname"];
date_default_timezone_set('Asia/Dhaka');
$snm3 = date("Y-m-d H:i:s");

//echo $snm3;


$sql = "SELECT id, devicename, username, ekey, command, udate,connect, ui  FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        echo $row["command"];
        $uid = $row["id"];
        //echo  $uid;
        }
        }
    }
} else {
    echo "0 results";
}




$sq1 = "UPDATE devices SET connect='$snm3' WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
    //echo "Record updated successfully";
} else {
   // echo "Error updating record: " . $conn->error;
}
$link->close();


header("location: updatetime.html");
exit;
?>
