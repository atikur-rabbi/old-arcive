


<HTML>
<TITLE>
Ebots Wifi Control
</TITLE>
<style>
body{  
    background: #2A3D4F;
    color: #FFF;
    text-align: center;   
  }
h1{
    font-family: Roboto, sans-serif; 
  font-size: 35px; 
  font-weight: 300; 
}
button {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
  font-size: 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text], select {
    width: 60%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
p{
    font-size: 25px;
}
 div.demo{text-align: center; width: 280px; float: left}
 div.demo > p{font-size: 20px}
</style>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <!--[if IE]><script type="text/javascript" src="excanvas.js"></script><![endif]-->
<script src="jquery.knob.min.js"></script>
<script>
function c(val)
{
document.getElementById("d").value=val;
}
function v(val)
{
document.getElementById("d").value+=val;
}

</script>
<script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

                // Example of infinite knob, iPod click wheel
               
            });
        </script>

 <BODY>
 <h1>Eduiot</h1>


 <div class="display"><input type="text" readonly size="15" id="d"></div>



<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['data'])){
         $data = stripslashes($_REQUEST['data']); // removes backslashes
		$data = mysqli_real_escape_string($con,$data);
        $query = "UPDATE `data` SET `data`='$data' WHERE id=2";
		$result = mysqli_query($con,$query);
        if($result){
			$category_query = "SELECT * FROM data";
	$run_query = mysqli_query($con,$category_query) or die(mysqli_error($con));
			if(mysqli_num_rows($run_query) > 0){
		while($row = mysqli_fetch_array($run_query)){
			$data1 = $row["data"];
			echo "<div class='form'><h1>Update</h1><form name='data' action='' method='post'>";
echo "<input name='data' class='knob' data-width='150' data-displayPrevious=true data-fgColor='#ffec03' data-skin='tron' data-cursor=true value='75' data-thickness='.2'>";
echo "Data = $data1";
			echo "<div class='container' style='margin:150px auto; text-align:center;'>";
  echo "<div class='GaugeMeter' id='PreviewGaugeMeter_2' data-percent='$data1' data-append=' %' data-size='200' data-theme='White' data-back='RGBa(0,0,0,.1)' data-animate_gauge_colors='1' data-animate_text_colors='1' data-width='15' data-label='Data' data-style='Arch' data-label_color='#FFF'>";
  echo "</div>";
  echo "</div>";
			}}
        }
	}

   
	
?>

<?php echo "hello" ?>


 <p>LED #1 <a  onclick='c("aon")'><button>ON</button></a>&nbsp;<a onclick='c("aof")'><button>OFF</button></a></p>
 <p>LED #2 <a name="add_tag" onclick='c(Id)' ><button>ON</button></a>&nbsp;<a ><button>OFF</button></a></p>
 
 <input class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-cursor=true value="75" data-thickness=".2">
 <input class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-thickness=".2" value="75">
 </BODY>
</HTML>
