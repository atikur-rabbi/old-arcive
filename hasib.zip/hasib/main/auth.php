<?php
session_start();
if(isset($_SESSION["username"]) && $_SESSION["username"] == "hasibarman"){
header("Location: database.php");
exit(); }
else
{
	echo "<div class='form'><h3>Sorry this is Admin page.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
	exit();
}
?>
