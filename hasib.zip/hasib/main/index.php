<!DOCTYPE HTML>
<html>
<head><meta name="viewport" content="width=device-width"/>
<title>ECEiot-15 welcome to IOT service</title>
<!-- STYLES & JQUERY 
================================================== -->
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/icons.css"/>
<link rel="stylesheet" type="text/css" href="css/slider.css"/>
<link rel="stylesheet" type="text/css" href="css/skinblue.css"/><!-- change skin color -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
<script src="js/jquery-1.9.0.min.js"></script><!-- the rest of the scripts at the bottom of the document -->
</head>
<body>
<!-- TOP LOGO & MENU
================================================== -->
<div class="grid">
	<div class="row space-bot">
		<!--Logo-->
		<div class="c4">
			<a href="index.php">
			<img src="images/logo.png" class="logo" alt="">
			</a>
		</div>
		<!--Menu-->
		<div class="c8">
			<nav id="topNav">
			<ul id="responsivemenu">
				<li class="active"><a href="index.php"><i class="icon-home homeicon"></i><span class="showmobile">Home</span></a></li>
				<li><a href="index2.html">Our Device</a>
					<li><a href="device.php">Device</a></li>
					<li><a href="https://thingspeak.com/channels/320979">Channel</a></li>	
<li><a href="login.php">Login</a></li>
<li><a href="registration.php">Sign Up</a></li>					
				<li><a href="404.html">Contact</a></li>
				
			</ul>
			</nav>
		</div>
	</div>
</div>
<div class="undermenuarea">
	<div class="boxedshadow">
	</div>
	<!-- SLIDER AREA
	================================================== -->
	<div id="da-slider" class="da-slider">
		<!--Slide 1-->
		<div class="da-slide">
			<h2> Have any Idea ! </h2>
			<p>
				Just share your idea about making any IOT works for any platform.We help to turn this idea to an service.
			</p>
		</div>
		<!--Slide 2-->
		<div class="da-slide">
			<h2>Internet Of Things</h2>
			<p>
				Want to control any devices through internet? We give you best service in this arena.
			</p>
		</div>
		<!--Slide 3-->
		<div class="da-slide">
			<h2> IOT Devlopment</h2>
			<p>
				Want to learn IOT development online? Hope we can be your right choice.
			</p>
		</div>
		<nav class="da-arrows">
		<span class="da-arrows-prev"></span>
		<span class="da-arrows-next"></span>
		</nav>
	</div>
</div>
<!-- UNDER SLIDER - BLACK AREA
================================================== -->
<div class="undersliderblack">
	<div class="grid">
		<div class="row space-bot">
			<div class="c12">
				<!--Box 1-->
				<div class="c4 introbox introboxfirst">
					<div class="introboxinner">
					<ul>
						<li class='inicon'><a href="login.php">Login</a></li>
						</ul>
					</div>
				</div>
				<!--Box 2-->
				<div class="c4 introbox introboxmiddle">
					<div class="introboxinner">
					<ul>
						<li class='inicon'><a href="registration.php">Sign Up</a></li>
						</ul>
					</div>
				</div>
				<!--Box 3-->
				<div class="c4 introbox introboxlast">
					<div class="introboxinner">
					<ul>
						<li class='inicon'><a href="404.html">IOT Devlopment</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="shadowunderslider">
</div>
<!-- START content area
================================================== -->
<div class="grid">
	<div class="row space-bot">
		<!--INTRO-->
		<div class="c12">
			<div class="royalcontent">

				<h1 class="titlemain" style="text-transform:none;">Why you should choose us</h1>
			</div>
		</div>
		<!--Box 1-->
		<div class="c4">
			<h2 class="title hometitlebg">Easy</h2>
			<div class="noshadowbox">
				<h5>Simple procedure</h5>
				<p>
					Share your idea about making any IOT service . 
				</p>
				<p class="bottomlink">
					<a href="#" class="neutralbutton"><i class="icon-link"></i></a>
				</p>
			</div>
		</div>
		<!--Box 2-->
		<div class="c4">
			<h2 class="title hometitlebg">IOT service</h2>
			<div class="noshadowbox">
				<h5>QUALITY</h5>
				<p>
					 We will give you best quality service.
				</p>
				<p class="bottomlink">
					<a href="#" class="neutralbutton"><i class="icon-link"></i></a>
				</p>
			</div>
		</div>
		<!--Box 3-->
		<div class="c4">
			<h2 class="title hometitlebg">Costing</h2>
			<div class="noshadowbox">
				<h5>Cheap Price</h5>
				<p>
					 Lot money will save in our service than others.
				</p>
				<p class="bottomlink">
					<a href="#" class="neutralbutton"><i class="icon-link"></i></a>
				</p>
			</div>
		</div>
	</div>
	<div class="row space-bot">
		<div class="c12">
			<div class="wrapaction">
				<div class="c9">
					<h1 class="subtitles">IOT-ECE Android App</h1>
					<p> Now you can use and see our service for your Android devices
				</p>
				</div>
				<div class="c3 text-center" style="margin-top:40px;">
					<div class="actionbutton">
						<i class=" icon-download-alt"></i> DOWNLOAD NOW
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!-- end grid -->

<!-- FOOTER
================================================== -->
<div id="wrapfooter">
	<div class="grid">
		<div class="row" id="footer">
			<!-- to top button  -->
			<p class="back-top floatright">
				<a href="#top"><span></span></a>
			</p>
			<div class="c6">
				<h2 class="title"><i class="icon-envelope-alt"></i> Contact</h2>
				<hr class="footerstress">
				<dl class="dl">
					<dt>Khulna,Bangladesh</dt>
					<dd><span>Telephone:</span>+8801927830141</dd>
					<dd>E-mail: <a href="404.html">iconhasib@gmail.com</a></dd>
				</dl>
				<ul class="social-links" style="margin-top:15px;">
					<li class="twitter-link smallrightmargin">
					<a href="404.html" class="twitter has-tip" target="_blank" title="Follow Us on Twitter">Twitter</a>
					</li>
					<li class="facebook-link smallrightmargin">
					<a href="404.html" class="facebook has-tip" target="_blank" title="Join us on Facebook">Facebook</a>
					</li>
					<li class="google-link smallrightmargin">
					<a href="404.html" class="google has-tip" title="Google +" target="_blank">Google</a>
					</li>
					<li class="linkedin-link smallrightmargin">
					<a href="404.html" class="linkedin has-tip" title="Linkedin" target="_blank">Linkedin</a>
					</li>
					<li class="pinterest-link smallrightmargin">
					<a href="404.html" class="pinterest has-tip" title="Pinterest" target="_blank">Pinterest</a>
					</li>
					<li class="skype-link smallrightmargin">
					<a href="404.html" class="skype has-tip" title="Skype" target="_blank">Skype</a>
					</li>
				</ul>
			</div>
			<!-- 4th column -->
			<div class="c6">
				<h2 class="title"><i class="icon-link"></i> About Us</h2>
				<hr class="footerstress">
				<h1 class="about">An iot sevice company</h1>
			</div>
			<!-- end 4th column -->
		</div>
	</div>
</div>
<!-- copyright area -->
<div class="copyright">
	<div class="grid">
		<div class="row">
			<div class="c4">
				 IOT-ECE &copy; 2017. All Rights Reserved.
			</div>
			<div class="c4">
				<span class="right">
				IOT develop Company </span>
			</div>
			<div class="c4">
				<span class="right">
				<a href="logout.php">Logout</a> </span>
			</div>
		</div>
	</div>
</div>
<!-- END CONTENT AREA -->
<!-- JAVASCRIPTS
================================================== -->
<!-- all -->
<script src="js/modernizr-latest.js"></script>

<!-- menu & scroll to top -->
<script src="js/common.js"></script>

<!-- slider -->
<script src="js/jquery.cslider.js"></script>

<!-- cycle -->
<script src="js/jquery.cycle.js"></script>
</body>
</html>