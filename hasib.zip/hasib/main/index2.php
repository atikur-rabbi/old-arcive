<!DOCTYPE HTML>
<html>
<head><meta name="viewport" content="width=device-width"/>
<title>IOT-ECE welcome to IOT service</title>
<!-- STYLES & JQUERY 
================================================== -->
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/main.css"/>
<link rel="stylesheet" type="text/css" href="css/icons.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
<script src="js/jquery-1.9.0.min.js"></script>
<script src="js/jquery.cycle"></script><!-- the rest of the scripts at the bottom of the document -->
</head>
<body>
<!-- TOP LOGO & MENU
================================================== -->
<div class="undermenuarea2">
	<div class="boxedshadow">
	</div>
<?php
$xml=simplexml_load_file("test.xml") or die("Error:Cannot create object");
$status=Array();
 $status[0]= $xml->state1;
 $status[1]= $xml->state2;
 $status[2]= $xml->state3;
 $status[3]= $xml->state4;
 $status[4]= $xml->state5;
 $status[5]= $xml->state6;
$xml->asXML("test.xml");
?>
		<!-- Banner -->
		<div id="form1">
			<section id="banner">
				<div class="inner">
					
					<div class="flex">

						<div>
							
							<h3>Light Intense</h3>
							<p>XX.XX %</p>
							
							<INPUT type=button id="bu2" value="Fan On" onClick=window.location='https://192.168.0.149/?fanon\'>
<INPUT type=button id="bu2" value="Fan Off" onClick=window.location='/fanoff?\'>
<INPUT type=button id="bu2" value="Fan Auto" onClick=window.location='/?fanauto\'>
							
							<h3>Light Status :</h3>
							<p>
							<?php
							echo $status[0];
							?>
							</p>
							
						</div>

						<div>
							
							<h3>Temperature</h3>
							<p>XX %</p>
							<form>
							<button id="bu2">Led on</button>
							<button id="bu2">Led on</button>
							<button id="bu2">Led on</button>
							</form>
							<h3>Fan Status :</h3>
							<p>
							<?php
							echo $status[2];
							?>
							</p>
							
						</div>

						<div>
							
							<h3>Water Level</h3>
							<p>XX CM</p>
							<form>
							<button id="bu2">Led on</button>
							<button id="bu2">Led on</button>
							<button id="bu2">Led on</button>
							</form>
							<h3>Pump Status :</h3>
							<p>
							<?php
							echo $status[4];
							?>
							</p>
							
						</div>

					</div>
</div>
</section>
</div>
</div>

<!-- END CONTENT AREA -->
<!-- JAVASCRIPTS
================================================== -->
<!-- all -->
<script src="js/modernizr-latest.js"></script>

<!-- menu & scroll to top -->
<script src="js/common.js"></script>

<!-- slider -->
</body>
</html>