<?php
$updatestate = $_GET["state"];
$xml=simplexml_load_file("test.xml") or die("Error:Cannot create object");
if($updatestate=="LED ON")
$xml->state1="LED ON";
else if($updatestate=="LED OFF")
	$xml->state1="LED OFF";
else if($updatestate=="LED AUTO ON")
	$xml->state2="LED AUTO ON";
else if($updatestate=="LED AUTO OFF")
	$xml->state2="LED AUTO OFF";
else if($updatestate=="FAN ON")
$xml->state3="FAN ON";
else if($updatestate=="FAN OFF")
	$xml->state3="FAN OFF";
else if($updatestate=="FAN AUTO ON")
	$xml->state4="FAN AUTO ON";
else if($updatestate=="FAN AUTO OFF")
	$xml->state4="FAN AUTO OFF";
else if($updatestate=="PUMP ON")
$xml->state5="PUMP ON";
else if($updatestate=="PUMP OFF")
	$xml->state5="PUMP OFF";
else if($updatestate=="PUMP AUTO ON")
	$xml->state6="PUMP AUTO ON";
else if($updatestate=="PUMP AUTO OFF")
	$xml->state6="PUMP AUTO OFF";
$xml->asXML("test.xml");
header("Location: index2.php");
?>