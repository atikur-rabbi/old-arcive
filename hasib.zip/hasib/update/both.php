<html>
<head><meta name="viewport" content="width=device-width"/>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/login.css"/>
<title>Update</title>

</head>
<body>

<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['data'])){
         $data = stripslashes($_REQUEST['data']); // removes backslashes
		$data = mysqli_real_escape_string($con,$data);
        $query = "UPDATE data SET `data`='$data' WHERE id=2";
		$result = mysqli_query($con,$query);
        if($result){
			$category_query = "SELECT * FROM data";
	$run_query = mysqli_query($con,$category_query) or die(mysqli_error($con));
			if(mysqli_num_rows($run_query) > 0){
		while($row = mysqli_fetch_array($run_query)){
			$data1 = $row["data"];
			echo "<div class='form'><h1>Update</h1><form name='data' action='' method='post'>";
echo "<input type='text' name='data' placeholder='data' required /><input type='submit' name='submit' value='Update' /></form><br /><br /></div>";
echo "Data = $data1";
			echo "<div class='container' style='margin:150px auto; text-align:center;'>";
  echo "<div class='GaugeMeter' id='PreviewGaugeMeter_2' data-percent='$data1' data-append=' %' data-size='200' data-theme='White' data-back='RGBa(0,0,0,.1)' data-animate_gauge_colors='1' data-animate_text_colors='1' data-width='15' data-label='Data' data-style='Arch' data-label_color='#FFF'>";
  echo "</div>";
  echo "</div>";
			}}
        }
	}
	else{
?>
<div class="form">
<h1>Update</h1>
<form name="data" action="" method="post">
<input type="text" name="data" placeholder="data" required />
<input type="submit" name="submit" value="Update" />
</form>
<br /><br />
<?php } ?>
</div>
<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script> 
<script src="js/jquery.AshAlom.gaugeMeter-2.0.0.min.js"></script> 
<script>
$(".GaugeMeter").gaugeMeter();
</script>
</body>
</html>