
<html>
<head><meta name="viewport" content="width=device-width"/>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/login.css"/>
<title>Registration</title>
<style>
body { background-color: #2980B9 }

.GaugeMeter {
  position: Relative;
  text-align: Center;
  overflow: Hidden;
  cursor: Default;
  display: inline-block;
}

.GaugeMeter SPAN, .GaugeMeter B {
  width: 54%;
  position: Absolute;
  text-align: Center;
  display: Inline-Block;
  color: RGBa(0,0,0,.8);
  font-weight: 100;
  font-family: "Open Sans", Arial;
  overflow: Hidden;
  white-space: NoWrap;
  text-overflow: Ellipsis;
  margin: 0 23%;
}

.GaugeMeter[data-style="Semi"] B {
  width: 80%;
  margin: 0 10%;
}

.GaugeMeter S, .GaugeMeter U {
  text-decoration: None;
  font-size: .60em;
  font-weight: 200;
  opacity: .6;
}

.GaugeMeter B {
  color: #000;
  font-weight: 200;
  opacity: .8;
}
</style>
</head>
<body>

<?php
	require('db.php');
			$category_query = "SELECT * FROM data";
	$run_query = mysqli_query($con,$category_query) or die(mysqli_error($con));
			if(mysqli_num_rows($run_query) > 0){
		while($row = mysqli_fetch_array($run_query)){
			$data1 = $row["data"];
			echo "<div class='container' style='margin:150px auto; text-align:center;'>";
  echo "<div class='GaugeMeter' id='PreviewGaugeMeter_2' data-percent='$data1' data-append=' %' data-size='200' data-theme='White' data-back='RGBa(0,0,0,.1)' data-animate_gauge_colors='1' data-animate_text_colors='1' data-width='15' data-label='Data' data-style='Arch' data-label_color='#FFF'>";
  echo "</div>";
  echo "</div>";
			}}
			?>
			<div style="font-size:80px;color:red;text-align:center";><a href="update.php">Back</div>
<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script> 
<script src="js/jquery.AshAlom.gaugeMeter-2.0.0.min.js"></script> 
<script>
$(".GaugeMeter").gaugeMeter();
</script>
</body>
</html>
