<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}


<?php

// Include config file
require_once 'config.php';

$snm = $_GET["ekey"];
$snm2 = $_GET["dname"];





$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //echo  $uid;
        }
        }
    }
} else {
    echo "0 results";
}






 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center;}
        .wrapper{ width: 350px; padding: 20px; margin: auto ; text-align: left;}
    </style>
</head>
<body>

    <div class="page-header">
        <h1>Hi, <b><?php echo $_SESSION['username']; ?></b>. Welcome to our Eduiot.</h1>
    </div>

    <div class="wrapper">
        <h2>Add Device</h2>
        <p>Enter Device name & ekey.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($devicename_err)) ? 'has-error' : ''; ?>">
                <label>Device name:<sup>*</sup></label>
                <input type="text" name="devicename"class="form-control" value="<?php echo $devicename; ?>">
                <span class="help-block"><?php echo $devicename_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($ekey_err)) ? 'has-error' : ''; ?>">
                <label>ekey:<sup>*</sup></label>
                <input type="ekey" name="ekey" class="form-control" value="<?php echo $ekey; ?>">
                <span class="help-block"><?php echo $ekey_err; ?></span>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
            
        </form>
    </div>    
</body>
</html>