<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "d1";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"];
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>
