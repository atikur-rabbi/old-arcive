<!doctype html>
<!--
Eduiot Technologies
-->

<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>


<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Introducing Lollipop, a sweet new take on Android.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Eduiot | IOT solution </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

    <!-- Page styles -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
  </head>
  <body >
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">

      <div class="android-header mdl-layout__header mdl-layout__header--waterfall">
        <div class="mdl-layout__header-row">
          <span class="android-title mdl-layout-title">
            <img class="android-logo-image" src="images/eduiotc.png">
          </span>
          <!-- Add spacer, to align navigation to the right in desktop -->
          <div class="android-header-spacer mdl-layout-spacer"></div>
          <div class="android-search-box mdl-textfield mdl-js-textfield mdl-textfield--expandable mdl-textfield--floating-label mdl-textfield--align-right mdl-textfield--full-width">
            
         
          </div>
          <!-- Navigation -->
        
          <span class="android-mobile-title mdl-layout-title">
            <img class="android-logo-image-mobile" src="images/eduiotc.png">
          </span>
          <button class="android-more-button mdl-button mdl-js-button mdl-button--icon mdl-js-ripple-effect" id="more-button">
            <i class="material-icons">more_vert</i>
          </button>
          <ul class="mdl-menu mdl-js-menu mdl-menu--bottom-right mdl-js-ripple-effect" for="more-button">
            <li ><a class="mdl-menu__item" href="settings.php" >Settings</a></li>
            <li ><a class="mdl-menu__item" href="logout.php" >Sign Out</a></li>
          </ul>
        </div>
      </div>

      <div class="android-drawer mdl-layout__drawer" class="scrollbar" id="style-3">
        <span class="mdl-layout-title">
          <img class="android-logo-image" src="images/eduiotw.png">
        </span>
        <nav class="mdl-navigation">
          <a class="mdl-navigation__link" href="account.php">Account</a>
          <a class="mdl-navigation__link" href="dashboard.php" >My Devices</a>
          <a class="mdl-navigation__link" href="adddevice.php" >Add Device</a>
          <a class="mdl-navigation__link" href="updatedevice.php" >Update Device</a>
          <a class="mdl-navigation__link" href="logout.php">Sign Out</a>
      
        </nav>
      </div>














      <div class="android-content mdl-layout__content" >
        <a name="top"></a>

 <div class="section mdl-typography--text-center" >




          <div class="logo-font android-slogan">Hello <b><?php echo $_SESSION['username']; ?></b>. </div>

        

</div>



  <div >
            <h2 class="copyright">© 2017 eduiot Technologies</h2>
  </div>
       

        
      </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>


  </body>
</html>
