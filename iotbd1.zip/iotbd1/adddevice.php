<?php
// Include config file
require_once 'config.php';
 


// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}



// Define variables and initialize with empty values
$devicename = $ekey =  "";
$devicename_err = $ekey_err =  "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate devicename
    if(empty(trim($_POST["devicename"]))){
        $devicename_err = "Please enter a device name.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM devices WHERE devicename = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_devicename);
            
            // Set parameters
            $param_devicename = trim($_POST["devicename"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $devicename_err = "This device is already taken.";
                } else{
                    $devicename = trim($_POST["devicename"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate ekey
    if(empty(trim($_POST['ekey']))){
        $ekey_err = "Please enter a ekey.";     
    } elseif(strlen(trim($_POST['ekey'])) < 6){
        $ekey_err = "ekey must have atleast 6 characters.";
    } else{
        $ekey = trim($_POST['ekey']);
    }
    

    
    // Check input errors before inserting in database
    if(empty($devicename_err) && empty($ekey_err) ) {
        
        // Prepare an insert statement
        $sql = "INSERT INTO devices (devicename,username, ekey) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_devicename, $param_username, $param_ekey);
            
            // Set parameters
            $param_devicename = $devicename;
            $param_username = $_SESSION['username'];
            $param_ekey = $ekey; // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to dashboard page
                header("location: dashboard.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Devices</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center;}
        .wrapper{ width: 350px; padding: 20px; margin: auto ; text-align: left;}
    </style>
</head>
<body>

    <div class="page-header">
        <h1>Hi, <b><?php echo $_SESSION['username']; ?></b>. Welcome to our <a href="index.php">Eduiot.</a></h1>
    </div>

    <div class="wrapper">
        <h2>Add Device</h2>
        <p>Enter Device name & ekey.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($devicename_err)) ? 'has-error' : ''; ?>">
                <label>Device name:<sup>*</sup></label>
                <input type="text" name="devicename"class="form-control" value="<?php echo $devicename; ?>">
                <span class="help-block"><?php echo $devicename_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($ekey_err)) ? 'has-error' : ''; ?>">
                <label>ekey:<sup>*</sup></label>
                <input type="ekey" name="ekey" class="form-control" value="<?php echo $ekey; ?>">
                <span class="help-block"><?php echo $ekey_err; ?></span>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
            
        </form>
    </div>    
</body>
</html>