<?php

// Include config file
require_once 'config.php';

$snm = $_GET["ekey"];
$snm2 = $_GET["dname"];




$sql = "SELECT id, devicename, username, ekey, ui FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        echo  $row["ui"];
        
        //echo  $uid;
        }
        }
    }
} else {
    echo "0 results";
}




$link->close();

?>
