<?php

// Include config file
require_once '../config.php';

$snm = $_GET["ekey"];
$snm2 = $_GET["dname"];





$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
        echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //echo  $uid;
        }
        }
    }
} else {
    echo "0 results";
}




$sq1 = "DELETE FROM devices WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
   ;
} else {
    echo "Error DELETE record: " . $conn->error;
}
$link->close();
 header("location: ../dashboard.php");

?>
