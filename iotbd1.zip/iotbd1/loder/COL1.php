<?php
    // if post with name is posted, set value to 1, else to 0
    for ($x = 0; $x <= 3; $x++) {
    $a[$x]= isset($_POST['check'][$x]) ? 1 : 0;
    //echo   $a[$x];
    }
    $a[4]=$_POST['check'][4];
   // echo   $a[4];
  //  echo  "<br>";
$all= $a[0].$a[1].$a[2].$a[3]."s". $a[4];
//echo $all;

    
for ($x = 0; $x <= 3; $x++) {
if ($a[$x]){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
}

$c[4]=$a[4];
// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "d2";
$snm3 = $all;

//echo $_POST['c[0]'];
//echo  $snm3 ;




$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //$ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}




$sq1 = "UPDATE devices SET command='$snm3' WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
      
   ;// echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        //$uid = $row["id"];
        $ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}


$link->close();

?>

<!DOCTYPE html>
<html lang="en">
    <head>
		<meta charset="UTF-8" />
<TITLE>
Ebots Wifi Control
</TITLE>

        <link rel="stylesheet" type="text/css" href="button.css" />
        <style>
body{  
    background: #2A3D4F;
    color: #FFF;
    text-align: center;   
  }
h1{
    font-family: Roboto, sans-serif; 
  font-size: 35px; 
  font-weight: 300; 
}
button {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
  font-size: 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text], select {
    width: 60%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
p{
    font-size: 25px;
}
 div.demo{text-align: center; width: 280px; float: left}
 div.demo > p{font-size: 20px}
</style>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="jquery.knob.min.js"></script>
    <script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                     

                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                         updatefrom();
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

                // Example of infinite knob, iPod click wheel
               
            });
        </script>
 <script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("view.php");
    setTimeout(loadstation, 2000);
}
</script>
	
    </head>
    <body>


 

     <div id="station_data"></div>


<form id="cform" method="post">
                <div class="switch demo3">
					<input type = 'checkbox' name = 'check[0]' value = '1' onchange = "updatefrom()" <?php  echo $c[0]?>> 
					<label><i></i></label>
				</div>
                <div class="switch demo3">
					<input type = 'checkbox' name = 'check[1]' value = '1' onchange = "updatefrom()" <?php  echo $c[1]?>> 
					<label><i></i></label>
				</div>
                <div class="switch demo3">
					<input type = 'checkbox' name = 'check[2]' value = '1' onchange = "updatefrom()" <?php  echo $c[2]?>> 
					<label><i></i></label>
				</div>
                <div class="switch demo3">
					<input type = 'checkbox' name = 'check[3]' value = '1' onchange = "updatefrom()" <?php  echo $c[3]?>> 
					<label><i></i></label>
				</div>


                <input id="input1"  NAME= 'check[4]'   class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-cursor=true value="<?php echo  $c[4];  ?>" data-thickness=".2">
</form>


<script>
function updatefrom(){
    document.getElementById("cform").submit();
}
</script>


    </body>
</html>
