
        
        
        <?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "d2";
$snm3 = $_GET["all"];

echo $_POST['c[0]'];
echo  $snm3 ;




$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //$ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}




$sq1 = "UPDATE devices SET command='$snm3' WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
      
   ;// echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        //$uid = $row["id"];
        $ucmd =  $row["command"];
        //echo  $ucmd;
        }
        }
    }
} else {
    echo "0 results";
}


$link->close();

?>


<!DOCTYPE html>
<html lang="en">
    <head>
		<meta charset="UTF-8" />

        <link rel="stylesheet" type="text/css" href="button.css" />
	
    </head>
    <body>
			
<?php
echo  "<br>";
for ($x = 1; $x <= 10; $x=$x+2) {
    $rest = substr($ucmd, $x,1);    // returns "f"
    echo  $rest;
    if ($rest=='1'){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
} 


?>	

        <form method="post" id="form1">
				<div class="switch demo3">
					<input  type="checkbox" name = 'c[0]' value = '1' <?php  echo $c[1]?>>
					<label><i></i></label>
				</div>
				
				<div class="switch demo3">
					<input type="checkbox" name = 'c[1]' value = '1'  <?php  echo $c[3]?>>
					<label><i></i></label>
				</div>
				
                <div class="switch demo3">
					<input  type="checkbox" name = 'c[2]' value = '1' <?php  echo $c[5]?>>
					<label><i></i></label>
				</div>
				
				<div class="switch demo3">
					<input type="checkbox" name = 'c[3]' value = '1' <?php  echo $c[7]?>>
					<label><i></i></label>
				</div>
                <input type="submit" value = 'Save Changes' />
		</form>

        <script type="text/javascript">
    // when page is ready
    $(document).ready(function() {
         // on form submit
        $("#form").submit(function() {
            // to each unchecked checkbox
            $(this + 'input[type=checkbox]:not(:checked)').each(function () {
                // set value 0 and check it
                $(this).attr('checked', true).val(0);
            });
        })
    })
</script>

<form method="post" id="form">
    <input type = 'checkbox' name = 'check[0]' value = '1'> 
    <input type = 'checkbox' name='check[1]' value = '1'>
    <input type="submit" value = 'Save Changes' />
</form>
			
        </div>
    </body>
</html>