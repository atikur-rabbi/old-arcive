$("#slider1").roundSlider({
    radius: 100,
    circleShape: "half-top",
    sliderType: "min-range",
    showTooltip: true,
    value: 50,
    tooltipFormat: "changeTooltip"
});

function changeTooltip(e) {
    var val = e.value;
    return val + "%";
};