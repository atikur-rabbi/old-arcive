<HTML>
<TITLE>
Ebots Wifi Control
</TITLE>
<style>
body{  
    background: #2A3D4F;
    color: #FFF;
    text-align: center;   
  }
h1{
    font-family: Roboto, sans-serif; 
  font-size: 35px; 
  font-weight: 300; 
}
button {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
  font-size: 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text], select {
    width: 60%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
p{
    font-size: 25px;
}
 div.demo{text-align: center; width: 280px; float: left}
 div.demo > p{font-size: 20px}
</style>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <!--[if IE]><script type="text/javascript" src="excanvas.js"></script><![endif]-->
<script src="jquery.knob.min.js"></script>
<script>
function c(val)
{
document.getElementById("d").value=val;
}
function v(val)
{
document.getElementById("d").value+=val;
}

</script>
<script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                      update1();

                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

                // Example of infinite knob, iPod click wheel
               
            });
        </script>

        <script>
		function update1() {
			            var x = document.getElementById("input1").value;
			            document.getElementById("demo").innerHTML = x;
                        document.getElementById("f1").submit();
			
		}
        </script>
        <script src="jquery.min.js"></script>
<script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("view.php");
    setTimeout(loadstation, 2000);
}
</script>

 <BODY>
 <h1>Eduiot</h1>


 <div class="display"><input type="text" readonly size="15" id="d"></div>



<div id="station_data"></div>
<?php echo "hello" ?>
<FORM id="f1" METHOD="LINK"  ACTION="update2.php">

</FORM>
<p id="demo">hello</p>
<input type="range" id="myRange" onchange="myrange()" value="90">
<script>
		function myrange() {
			var x = document.getElementById("myRange").value;
			document.getElementById("demo").innerHTML = x;
			
		}
</script>

        <?php
        if( $_POST["name"] || $_POST["age"] ) {
            if (preg_match("/[^A-Za-z'-]/",$_POST['name'] )) {
                die ("invalid name and name should be alpha");
            }
            echo "Welcome ". $_POST['name']. "<br />";
            echo "You are ". $_POST['age']. " years old.";
            
            
        }
        ?>

        
      <form action = "<?php $_PHP_SELF ?>" method = "POST">
         Name: <input type = "text" name = "name" />
         Age: <input type = "text" name = "age" />
         <input type = "submit" />
      </form>

 <p>LED #1 <a  onclick='c("aon")'><button>ON</button></a>&nbsp;<a onclick='c("aof")'><button>OFF</button></a></p>
 <p>LED #2 <a name="add_tag" onclick='c(Id)' ><button>ON</button></a>&nbsp;<a ><button>OFF</button></a></p>
 
 <input class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-cursor=true value="75" data-thickness=".2">
 <input class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-thickness=".2" value="75">




   
   </body>
</html>

