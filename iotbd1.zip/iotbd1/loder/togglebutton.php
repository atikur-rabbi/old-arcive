



<HTML>
<TITLE>
Ebots Wifi Control
</TITLE>
 <link rel="stylesheet" type="text/css" href="button.css" />
<style>
body{  
    background: #2A3D4F;
    color: #FFF;
    text-align: center;   
  }
h1{
    font-family: Roboto, sans-serif; 
  font-size: 35px; 
  font-weight: 300; 
}
button {
    width: 30%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
  font-size: 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text], select {
    width: 60%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
p{
    font-size: 25px;
}
 div.demo{text-align: center; width: 280px; float: left}
 div.demo > p{font-size: 20px}
</style>
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
        <!--[if IE]><script type="text/javascript" src="excanvas.js"></script><![endif]-->
<script src="jquery.knob.min.js"></script>
<script>
function c(val)
{
document.getElementById("d").value=val;
}
function v(val)
{
document.getElementById("d").value+=val;
}

</script>
<script>
            $(function($) {

                $(".knob").knob({
                    change : function (value) {
                        //console.log("change : " + value);
                     

                    },
                    release : function (value) {
                        //console.log(this.$.attr('value'));
                        console.log("release : " + value);
                         update1();
                    },
                    cancel : function () {
                        console.log("cancel : ", this);
                    },
                    /*format : function (value) {
                        return value + '%';
                    },*/
                    draw : function () {

                        // "tron" case
                        if(this.$.data('skin') == 'tron') {

                            this.cursorExt = 0.3;

                            var a = this.arc(this.cv)  // Arc
                                , pa                   // Previous arc
                                , r = 1;

                            this.g.lineWidth = this.lineWidth;

                            if (this.o.displayPrevious) {
                                pa = this.arc(this.v);
                                this.g.beginPath();
                                this.g.strokeStyle = this.pColor;
                                this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, pa.s, pa.e, pa.d);
                                this.g.stroke();
                            }

                            this.g.beginPath();
                            this.g.strokeStyle = r ? this.o.fgColor : this.fgColor ;
                            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d);
                            this.g.stroke();

                            this.g.lineWidth = 2;
                            this.g.beginPath();
                            this.g.strokeStyle = this.o.fgColor;
                            this.g.arc( this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
                            this.g.stroke();

                            return false;
                        }
                    }
                });

                // Example of infinite knob, iPod click wheel
               
            });
        </script>

        <script>
		function update1() {
			            var x = document.getElementById("input1").value;
			            //document.getElementById("d").innerHTML = x;
                       document.getElementById("f1").submit();
			
		}
        </script>
        <script src="jquery.min.js"></script>
<script>$(document).ready(function(){    
    loadstation();
});

function loadstation(){
    $("#station_data").load("view.php");
    setTimeout(loadstation, 2000);
}
</script>

 <BODY>
 <h1>Eduiot</h1>





<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "d1";
$val = "d1";
$a= "checked";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        $val= $row["command"];
        }
    }
} else {
    echo "0 results";
}
//echo  $val; 
$link->close();
?>
<div id="station_data"></div>



<FORM id="f1" METHOD="LINK"  ACTION="update4.php">
	            <div class="switch demo3">
					<input type="checkbox" name="cm" value="70" <?php echo  $a;?>>
					<label><i></i></label>
				</div>
				
				<div class="switch demo3">
					<input type="checkbox" name="c2" value="100" checked>
					<label><i></i></label>
				</div>
                <input id="input1"  NAME="cm1"   class="knob" data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-cursor=true value="<?php echo  $val;  ?>" data-thickness=".2">

</FORM>




 
 <input class="knob" readonly data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-cursor=true value="<?php echo  $val;  ?>" data-thickness=".2">
 <input class="knob" readonly data-width="150" data-displayPrevious=true data-fgColor="#ffec03" data-skin="tron" data-thickness=".2" value="<?php echo  $val;  ?>">
 </BODY>
</HTML>
