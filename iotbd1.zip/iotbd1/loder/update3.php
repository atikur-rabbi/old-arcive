<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "d1";
$snm3 = $_GET["cm"];




$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2){
                
        //echo "id: " . $row["id"]. " - Devicename: " . $row["devicename"].  " - Username: " . $row["username"].  " - Key: " . $row["ekey"].  " - Command: " . $row["command"].  " </br> ";
        $uid = $row["id"];
        //echo  $uid;
        }
        }
    }
} else {
    echo "0 results";
}




$sq1 = "UPDATE devices SET command='$snm3' WHERE id=$uid";

if ($link->query($sq1) === TRUE) {
      header("location: knob.php");
                    exit;
    //echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}
$link->close();

?>
