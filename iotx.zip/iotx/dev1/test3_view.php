<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "test";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        $t = $row["command"];
        
        }
    }
} else {
    echo "0 results";
}


//echo $t[0];  
//echo $t[1];
//echo $t[2];

//echo $t[3];  
//echo $t[4];
//echo $t[5];

//echo $t[6];  
//echo $t[7];

for ($x = 0; $x <= 3; $x++) {
if ($t[$x]){
    $c[$x]= "checked";
    //echo   $c[$x];
    }
    else
    $c[$x]= "";
}

$c[4]=10*$t[4] + $t[5] ;
 //echo $c[4];

$link->close();
?>


<html>
  <head>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.lime-yellow.min.css" />
    <script>

 function updatefrom(){
document.getElementById("form").submit();
 alert('form was submitted');
}
      $(function () {

        $('form').on('change', function (e) {

          e.preventDefault();
      
          $.ajax({
            type: 'post',
            url: 'test3.php',
            data: $('form').serialize(),
            success: function () {
             // alert('form was submitted');
            }
          });

        });

      });



    </script>



  </head>
  <body>



    <div class="container ">
    <form  id="cform">

<label for="switch1" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[0]' type="checkbox" id="switch1" class="mdl-switch__input" value = '1' <?php  echo $c[0]?>>
  <span class="mdl-switch__label">Light</span>
</label>
<label for="switch2" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
    <span class="mdl-switch__label">Fan</span>
  <input name = 'check[1]' type="checkbox" id="switch2" class="mdl-switch__input" value = '1'<?php  echo $c[1]?>> 
</label>
<label for="switch3" class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[2]' type="checkbox" id="switch3" class="mdl-switch__input" value = '1' <?php  echo $c[2]?>>
  <span class="mdl-switch__label">TV</span>
</label>
<label for="switch4"  class="mdl-switch mdl-js-switch mdl-js-ripple-effect">
  <input name = 'check[3]' type="checkbox" id="switch4" class="mdl-switch__input" value = '1' <?php  echo $c[3]?>> 
  <span class="mdl-switch__label">Pump</span>
</label>

<input class="mdl-slider mdl-js-slider" type="range"
  min="0" max="100"  name = 'check[4]' tabindex="0" value="<?php echo  $c[4];  ?>">


     
    </form>
  </div>


    

<script src="https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.min.js"></script>

  </body>
</html>