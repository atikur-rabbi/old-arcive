<?php

// Include config file
require_once 'config.php';

$snm = "12345678";
$snm2 = "test";

 

$sql = "SELECT id, devicename, username, ekey, command FROM devices ";
$result = $link->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["ekey"]==$snm && $row["devicename"]==$snm2)
        echo  $row["command"];
        }
    }
} else {
    echo "0 results";
}

$link->close();
?>
