
<?php

$sql = "SELECT keyid, data, cmd FROM devices";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "".$row["keyid"]."<br>".$row["data"]." <br>".$row["cmd"]."<br>";
    }

} else {
    echo "0 results";
}
?>