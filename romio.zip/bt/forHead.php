<title>Hello, world!</title>
<link rel="icon" href="logo.jpg">
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">
<script type="text/javascript" scr="js/bootstrap.min.js"></script>