<?php
	//including config file
	include('configuration.php');
	$conn;
	try
	{
		$conn = new PDO("mysql:host=$host;dbname=$db",$user,$pw);
	}
	catch(PDOException $e)
	{
		die("Couldn't Connect");
	}
	$login = 0;
?>

<?php
	if(isset($_POST['submit']))
	{
		if(!empty($_POST['username']) && !empty($_POST['password']))
		{
			$user = $_POST['username'];
			$pass = $_POST['password'];
			$data = $conn->query("SELECT * FROM admintable WHERE username = '$user' AND password = '$pass'");
			if($data->rowCount() == 1)
			{
				$login = 1;
			}
			else
			{
				$login = 0;
			}
		}
		else
		{
			$login = 0;
		}
	}
	else
	{
		$login = 0;
	}
?>

<!doctype html>
<html lang="en">
  <head>
    <?php include('forHead.php'); ?>
  </head>
  <body>

  	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
	  <a class="navbar-brand" href="#"> <img src="logo.jpg" alt="Logo" style="width:40px;"></a>
	  <?php if($login == 1) { ?>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="collapsibleNavbar">
	    <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="show.php">Show Employees</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="register.php">Register new employee</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="search.php">Search</a>
	      </li>    
	    </ul>
	  </div> 
	  <?php } else { ?>
	  <span class="navbar-text">Admin Log In</span>
	  <form class="form-inline" action="#" method="POST">
	  	<input class="form-control" type="text" name="username" placeholder="Admin Username">
	  	<input class="form-control" type="password" name="password" placeholder="Admin Password">
	  	<button class="btn btn-primary" type="submit" name="submit">Log In</button>
	  </form> 
	  <?php } ?>

	  <?php if(isset($_POST['submit'])) {
	  	if($login == 0) { ?>
	  		<span class="navbar-text"><div class="alert alert-danger">Wrong Username or Password</div></span>
	  	<?php }
	  } ?>
	</nav>
	<br>
  </body>
</html>