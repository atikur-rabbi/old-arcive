<?php
	//including config file
	include('configuration.php');
	
    $conn = new PDO("mysql:host=$host;dbname=$db",$user,$pw);

    $name = "";
	$sex = "";
	$address = "";
	$rank = "";
	$ok = 0;
	$query = "";
	$sum = 0;
?>

<?php
	if(isset($_POST['submit']))
	{
		$ok = 1;
		$name = $_POST['name'];
		$sex = $_POST['sex'];
		$address = $_POST['address'];
		$rank = $_POST['rank'];
		$building = $_POST['building'];
		$query = "INSERT INTO Employee (name, sex, address, building, rank) VALUES ('$name', '$sex', '$address', '$building', '$rank')";
		if($conn->query($query))
		{
			header('location:show.php');
		}
		else
		{
			echo "INSERT FAILED";
		}
	}
	else
	{
		$ok = 0;
	}
?>

<?php
	function add()
	{
		$sum = 125 + 5;
		return $sum;
	}
?>

<!doctype html>
<html lang="en">
  <head>
    <?php include('forHead.php'); ?>

  </head>
  <body>
	<h1 class="text-center"><span class="badge badge-light">My form</span></h1>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<p class="text-center"><span class="badge badge-info">Input Section</span></p>
				<form method="post" action="#">
					<div class="form-group">
						<span class="badge badge-secondary">Name</span> <input type="text" name="name" class="form-control" placeholder="Enter your full name">
					</div>
						<span class="badge badge-secondary">Sex</span><br>
						<label class="radio-inline"><input type="radio" name="sex" value="Male">Male</label>
						<label class="radio-inline"><input type="radio" name="sex" value="Female">Female</label>
						<label class="radio-inline"><input type="radio" name="sex" value="Other">Other</label>
					<div class="form-group">
						<span class="badge badge-secondary">Address</span> <input type="address" name="address" class="form-control" placeholder="Enter address">
					</div>
					<div class="form-group">
						<span class="badge badge-secondary">Working Building</span>
						<select class="form-control" name="building">
					        <option>Administrator Building</option>
					        <option>1st Academic Building</option>
					        <option>2nd Academic Building</option>
					        <option>3rd Academic Building</option>
					     </select>
					</div>
					<div class="form-group">
						<span class="badge badge-secondary">Rank/Position</span> <input type="rank" name="rank" class="form-control" placeholder="Enter your rank/position">
					</div>
					<div class="form-group">
						<button class="btn btn-dark btn-block" name="gfid">Get Fingerprint ID (Enroll your finger on the fingerprint device)</button>
					</div>
					<?php if(isset($_POST['gfid'])) { ?>
						<div class="form-group">
							<span class="badge badge-secondary">SUM =  <?php echo add(); ?> </span>
						</div>
					<?php } ?>
					<div class="form-group" align="center">
						<button type="submit" name="submit" class="btn btn-primary">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	
  </body>
</html>