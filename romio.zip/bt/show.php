<?php
	include('configuration.php');
	$conn;
	$query = "SELECT * FROM employee";
	$ok = 1;
    try
    {
    	$conn = new PDO("mysql:host=$host;dbname=$db",$user,$pw);
    	if(isset($_REQUEST['did']))
    	{
    		$did = $_REQUEST['did'];
    		if(!$conn->exec("DELETE from Employee WHERE id = '$did'"))
    		{
    			echo "DELETE FAILED";
    		}
    	}
    }
    catch(PDOException $e)
    {
    	$ok = 0;
    }
?>

<?php
	if(isset($_POST['allsubmit']))
	{
		if(!empty($_POST['allsearch']))
		{
			$s = $_POST['allsearch'];
			$query = "SELECT * FROM employee WHERE name LIKE '%$s%' OR sex = '$s' OR building LIKE '%$s%' OR address LIKE '%$s%' OR rank LIKE '%$s%'";
		}
	}

	if(isset($_POST['catsubmit']))
	{
		$building = $_POST['building'];
		$rank = $_POST['rank'];
		$query = "SELECT * FROM employee WHERE building = '$building' AND rank = '$rank'";
	}

?>

<!DOCTYPE html>
<html>
<head>
	<?php include('forHead.php'); ?>
</head>
<body>
	<div class="container">
		<div class="row" style="padding-left: 320px">
			<div class="col">
				<h2 style="padding-left: 120px"><span class="badge badge-info">Employee List</span></h2>
				<form class="form-inline" method="post" action="#">
					<h3><span class="badge badge-info">Enter your query</span></h3><input type="text" name="allsearch" class="form-control" placeholder="Enter your query here"><button type="submit" name="allsubmit" class="btn btn-primary">Go</button>
				</form>
			</div>
		</div>
		<div class="row" style="padding-left: 320px">
			<div class="col">
				<form class="form-inline" method="post" action="#">
				<select class="form-control" name="building">
					<option>Administrator Building</option>
			        <option>1st Academic Building</option>
			        <option>2nd Academic Building</option>
			        <option>3rd Academic Building</option>
				</select>
				<select class="form-control" name="rank">
					<?php
					$data = $conn->query("SELECT DISTINCT rank FROM employee");
					if($data->rowCount() > 0)
					{
						foreach ($data as $row)
						{ ?>
							<option> <?php echo $row['rank']; ?></option>
						<?php }
					} ?>
				</select>
				<button class="form-control btn btn-primary" name="catsubmit">Go</button>
				</form>
			</div>
		</div>
		<div class="row" style="padding: 30px">
			<div class="col">
				<?php if($ok == 1){ ?>
					<table class="table table-bordered table-hover">
						<thead class="thead-dark">
							<th><p class="text-center">Name</p></th>
							<th><p class="text-center">Sex</p></th>
							<th><p class="text-center">Address</p></th>
							<th><p class="text-center">Building</p></th>
							<th><p class="text-center">Rank</p></th>
							<th><p class="text-center">Action</p></th>
						</thead>
						<tbody>
							<?php
							$info = $conn->query($query);
							$c = $info->rowCount();
							if($c == 0)
							{?>
								<div class="alert alert-warning">
									<p class="text-center"><strong>No entry matches your query</strong></p>
								</div>
							<?php } else { ?>
								<div class="alert alert-info">
									<p class="text-center"><strong> <?php echo "There are ".$c." entries";?></strong></p>
								</div>
							<?php }
							if($c != 0) foreach ($info as $row) { ?>
								<tr class="table-primary">
									<td><p class="text-center"><?php echo $row['name']; ?></p></td>
									<td><p class="text-center"><?php echo $row['sex']; ?></p></td>
									<td><p class="text-center"><?php echo $row['address']; ?></p></td>
									<td><p class="text-center"><?php echo $row['building']; ?></p></td>
									<td><p class="text-center"><?php echo $row['rank']; ?></p></td>
									<td>
										<div class="btn-group">
										  <a href="update.php?eid=<?php echo $row['id']; ?>" class="btn btn-primary" roll="button">Update</a>
										  <a href="show.php?did=<?php echo $row['id']; ?>" class="btn btn-danger" roll="button">Delete</a>
										</div>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
					<?php } else { ?>
					<div class="alert alert-danger">
						<p class="text-center"><strong>Sorry!!! Databse Connection Failed</strong></p>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</body>
</html>