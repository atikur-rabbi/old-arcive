<?php
	//including config file
	include('configuration.php');
	
    $conn = new PDO("mysql:host=$host;dbname=$db",$user,$pw);

    $name = "";
	$sex = "";
	$address = "";
	$rank = "";
	$ok = 0;
	$query = "";
	$id = -1;
?>

<?php
	if(isset($_REQUEST['eid']))
	{
		$id = $_REQUEST['eid'];
	}
	if(isset($_REQUEST['update']))
	{
		$ok = 1;
		$name = $_POST['name'];
		$sex = $_POST['sex'];
		$address = $_POST['address'];
		$rank = $_POST['rank'];
		$building = $_POST['building'];
		$query = "UPDATE Employee SET name = '$name', sex = '$sex', address = '$address', building = '$building', rank = '$rank' WHERE id = '$id'";
		if($conn->query($query))
		{
			header('location:show.php');
		}
		else
		{
			echo "UPDATE FAILED";
		}
	}
	else
	{
		$ok = 0;
	}
?>

<!doctype html>
<html lang="en">
  <head>
    <?php include('forHead.php'); ?>
  </head>
  <body>
	<h1 class="text-center"><span class="badge badge-light">Update form</span></h1>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<p class="text-center"><span class="badge badge-info">Update Section</span></p>
				<?php
					$res = $conn->query("SELECT * FROM Employee WHERE id = '$id'");
					foreach ($res as $info)
					{
						$name = $info['name'];
						$sex = $info['sex'];
						$address = $info['address'];
						$rank = $info['rank'];
						break;
					}
				?>
				<form method="post" action="#">
					<div class="form-group">
						<span class="badge badge-secondary">Name</span> <input type="name" name="name" class="form-control" value="<?php echo($name); ?>" placeholder="Enter your full name">
					</div>
						<span class="badge badge-secondary">Sex</span><br>
						<?php
							if($sex == "Male")
							{?>
								<label class="radio-inline"><input type="radio" name="sex" value="Male" checked>Male</label>
							<?php } else {?>
								<label class="radio-inline"><input type="radio" name="sex" value="Male">Male</label>
							<?php
								} if($sex == "Female"){ ?>
								<label class="radio-inline"><input type="radio" name="sex" value="Female" checked>Female</label>
								<?php } else {?>
								<label class="radio-inline"><input type="radio" name="sex" value="Female">Female</label>
							<?php } if($sex == "Other") {?>
								<label class="radio-inline"><input type="radio" name="sex" value="Other" checked >Other</label>
								<?php } else { ?>
								<label class="radio-inline"><input type="radio" name="sex" value="Other">Other</label>
								<?php } ?>
					<div class="form-group">
						<span class="badge badge-secondary">Address</span> <input type="address" name="address" class="form-control" value="<?php echo($address); ?>" placeholder="Enter address">
					</div>
					<div class="form-group">
						<span class="badge badge-secondary">Working Building</span>
						<select class="form-control" name="building">
					        <option>Administrator Building</option>
					        <option>1st Academic Building</option>
					        <option>2nd Academic Building</option>
					        <option>3rd Academic Building</option>
					     </select>
					</div>
					<div class="form-group">
						<span class="badge badge-secondary">Rank/Position</span> <input type="rank" name="rank" class="form-control" value="<?php echo($rank); ?>" placeholder="Enter your rank/position">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary" name="update">Update Entry</button>
					</div>
				</form>
			</div>
		</div>
	</div>
  </body>
</html>