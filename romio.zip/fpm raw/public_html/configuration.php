<?php
	$host = 'localhost';
	$user = 'id3537724_fpmdb';
	$pw = 'fpadmin';
	$db = 'id3537724_fpm';
?>