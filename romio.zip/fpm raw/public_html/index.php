<?php
	//including config file
	include('configuration.php');
	$conn;
	try
	{
		$conn = new PDO("mysql:host=$host;dbname=$db",$user,$pw);
	}
	catch(PDOException $e)
	{
		//die("Couldn't Connect");
	}
?>

<?php 
	if(isset($_GET['data']))
	{
		$user = $_GET['data'];
		$pass = "none";
		$q = "INSERT INTO admintable (username, password) VALUES ('$user', '$pass')";
		$conn->exec($q);
	}
?>