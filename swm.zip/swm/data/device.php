
<?php

require_once 'config.php';
$cmd;

	if(isset($_GET["keyid"])){
	$keyid =$_GET["keyid"];
   // echo $keyid."<br>";

	if(isset($_GET["data"])){
	$data = $_GET["data"];
	//echo $data."<br>";


	require_once 'updatedata.php';
    }


	require_once 'viewcmd.php';
    }
$conn->close();

?>
