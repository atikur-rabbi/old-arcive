
<?php

$sq1 = "UPDATE devices SET data='$data' WHERE keyid=$keyid";

if ($conn->query($sq1) === TRUE) {
    echo "okey_";
} else {
    echo "error";
}


?>