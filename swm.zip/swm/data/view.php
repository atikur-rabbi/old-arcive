
<?php

require_once 'config.php';
$cmd;

	if(isset($_GET["keyid"])){
	$keyid =$_GET["keyid"];
   // echo $keyid."<br>";

	require_once 'viewone.php';
    }
$conn->close();


 require_once 'view.html';
?>
