
<?php

$sql = "SELECT * FROM devices WHERE keyid LIKE '$keyid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "".$row["data"]."<br>";
    }

} else {
    echo "0 results";
}
?>