<?php

require_once 'config.php';


	if(isset($_GET["keyid"])){
	$keyid =$_GET["keyid"];
   // echo $keyid."<br>";

	if(isset($_GET["level"])){
	$level = $_GET["level"];
	//echo $data."<br>";


	require_once 'updatelevel.php';
    }
    
    }
$conn->close();

?>
