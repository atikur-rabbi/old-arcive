
<?php

$sq1 = "UPDATE devices SET level='$level' WHERE keyid=$keyid";

if ($conn->query($sq1) === TRUE) {
    echo "okey_";
} else {
    echo "error";
}


?>