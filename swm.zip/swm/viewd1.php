<?php

// Include config file
require_once 'config.php';

$keyid = "1103";
$level;

 

$sql = "SELECT keyid, level FROM devices ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        {
            if ($row["keyid"]==$keyid)
        echo  $row["level"];
        }
    }
} else {
    echo "0 results";
}

$conn->close();
?>
