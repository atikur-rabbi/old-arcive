<?php


// Include config file
require_once 'config.php';





?>
