A Pen created at CodePen.io. You can find this one at https://codepen.io/niewdesign/pen/wgNRWa.

 Demo playground for one of the IoT-code project.
See all of them at http://iot-code.com